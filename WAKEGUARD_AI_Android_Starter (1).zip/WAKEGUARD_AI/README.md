# WAKEGUARD AI — Android starter project

This is an Android Studio Kotlin project scaffold for a smart alarm with:
- One daily alarm time using Android AlarmManager
- A looping system alarm tone
- A full-screen alarm notification
- Front-camera face/eye-open probability detection using ML Kit
- A 2-minute eye-open verification attempt; if it fails, the alarm remains active

## Build an APK
1. Install Android Studio (latest stable) on a computer.
2. Open this `WAKEGUARD_AI` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK 35 platform if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator with a front camera.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important prototype limitations
- This is a starter implementation, not a tested release APK. It must be built and tested on a real phone.
- Android manufacturers may restrict background alarms, full-screen notifications, or battery use. Allow alarms/notifications and disable battery optimization for reliable testing where Android offers that setting.
- Some devices do not expose eye-open probabilities reliably. The app should be tested in normal room lighting.
- The current sample schedules one alarm and does not yet persist/recreate alarms after reboot.
- The 2-minute check is a prototype: it accumulates eye-open samples and is not a medical or guaranteed wakefulness detector.
- The app uses the front camera only during the check. ML Kit processing is on-device; this sample does not upload camera frames.
- Sound loudness depends on the phone's alarm-volume setting. Increase the Alarm volume in Android settings.
- Before publishing, add a proper launcher icon, accessibility review, reboot rescheduling, multiple alarms, and device-specific testing.
