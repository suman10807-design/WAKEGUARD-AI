package com.wakeguard.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

class WakeCheckActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var preview: PreviewView
    private var openSeconds = 0
    private var lastTick = System.currentTimeMillis()
    private var passed = false
    private val executor = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        FaceDetection.getClient(FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 35, 20, 20)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        status = TextView(this).apply {
            text = "Keep your eyes open for 2 minutes"; textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
        }
        preview = PreviewView(this)
        layout.addView(status)
        layout.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 20)
        } else startCamera()
        object : CountDownTimer(120_000, 1000) {
            override fun onTick(millis: Long) {
                val remaining = millis / 1000
                status.text = "Eye check: ${remaining / 60}:${(remaining % 60).toString().padStart(2,'0')} remaining\nKeep looking at the camera. Eyes open: $openSeconds / 120 seconds"
                if (openSeconds >= 120) { passed = true; finishAlarm() }
            }
            override fun onFinish() {
                if (!passed) {
                    status.text = "Check not passed. Alarm continues. Try again."
                    openSeconds = 0
                    recreate()
                }
            }
        }.start()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy ->
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                detector.process(image)
                    .addOnSuccessListener { faces ->
                        val face = faces.firstOrNull()
                        val left = face?.leftEyeOpenProbability
                        val right = face?.rightEyeOpenProbability
                        val eyesOpen = left != null && right != null && left > 0.65f && right > 0.65f
                        val now = System.currentTimeMillis()
                        if (eyesOpen) {
                            if (now - lastTick >= 1000) {
                                openSeconds++
                                lastTick = now
                            }
                        } else {
                            // Require a continuous eye-open period; closing either eye resets progress.
                            openSeconds = 0
                            lastTick = now
                        }
                    }.addOnCompleteListener { proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, androidx.camera.core.CameraSelector.DEFAULT_FRONT_CAMERA, previewUseCase, analysis)
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun finishAlarm() {
        stopService(android.content.Intent(this, AlarmService::class.java))
        Toast.makeText(this, "Wake-up check passed!", Toast.LENGTH_LONG).show()
        finish()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else status.text = "Camera permission is needed for the eye check. Alarm will continue."
    }
    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
